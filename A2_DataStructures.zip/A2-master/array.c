#include "array.h"
#include <stdlib.h>
#include <stdio.h>


struct Array *newArray( struct memsys *memsys, unsigned int width, unsigned int capacity){

  int arrayLocation = memmalloc (memsys, sizeof (struct Array));
  struct Array array;
  array.width = width;
  array.capacity = capacity;
  array.nel = 0;
  array.data = memmalloc(memsys, width * capacity);
  setval(memsys,&array, sizeof(struct Array),arrayLocation);
  char*memory = memsys->memory;
  return (struct Array*)&memory[arrayLocation];
}
void writeItem(struct memsys*memsys, struct Array*array,unsigned int index, void*src){
  if(index > array->nel || index >= array->capacity){

    printf("bad index in writeItem\n");
  }
  else{

    setval(memsys,src,array->width,array->data+index*array->width);
    if(index == array->nel){
      array->nel++;
    }
  }
}
void readItem(struct memsys*memsys, struct Array*array,unsigned int index, void*dest){

  if(array->nel <= index){

      printf("Bad index in readItem\n");


  }
  else{
    getval(memsys,dest,array->width,array->data+index*array->width);
  }
}
void freeArray(struct memsys*memsys, struct Array*array){
  memfree(memsys,array->data);
}

void contract(struct memsys*memsys, struct Array*array){
  if(array->nel==0){
    printf("array size of zero cant contract\n");
  }
  else{
    array->nel--;
  }
}
void appendItem(struct memsys*memsys,struct Array*array, void*src){
  writeItem(memsys,array,array->nel,src);
}
void insertItem(struct memsys*memsys,struct Array*array,unsigned int index,void*src){
  int hold = memmalloc(memsys,array->width);
  char*memory = memsys->memory;
  for(int i = array->nel-1;i> index; i--){
    readItem(memsys,array,i,&memory[hold]);
    writeItem(memsys,array,i+1,&memory[hold]);
  }
  writeItem(memsys,array,index,src);
  memfree(memsys,hold);
}
void prependItem(struct memsys*memsys,struct Array*array,void*src){
  insertItem(memsys,array,0,src);
}
void deleteItem(struct memsys*memsys,struct Array*array,unsigned int index){
  char*memory = memsys->memory;
  int hold = memmalloc(memsys,array->width);
  for(int i = index + 1; i < array->nel;i++){

    readItem(memsys,array,i,&memory[hold]);
    writeItem(memsys,array,i-1,&memory[hold]);
  }
  contract(memsys,array);
}
int findItem(struct memsys*memsys,struct Array*array,int (*compar)(const void*,const void*),void *target){
  char*memory = memsys->memory;
  int hold = memmalloc(memsys,array->width);
  for(int i = 0; i<array->nel;i++){
    readItem(memsys,array,i,&memory[hold]);
    int result = compar(target,&memory[hold]);
    if(result ==0){
      memfree(memsys,hold);
      return i;
    }
  }
  memfree(memsys,hold);
  return -1;
}
int searchItem(struct memsys*memsys,struct Array*array,int (*compar)(const void*,const void*),void *target){
    int hI = array->nel -1;
    int lI = 0;
    int mI = hI + lI / 2;
    int hold = memmalloc(memsys,array->width);
    char*memory = memsys->memory;
    int result;
    while(lI<=hI){
      readItem(memsys,array,mI,&memory[hold]);
      result = compar(&memory[hold],target);
      if(result == 0){
        memfree(memsys,hold);
        return mI;
      }
      if(result > 0){
        lI = mI + 1;

      }
      else{
        hI = mI -1;
      }
      mI = lI + hI / 2;
    }
    memfree(memsys,hold);
    return -1;
}
